#!/bin/bash
exec > logfile.txt
date

echo "Deleting golden interface if it exists"
echo vvdntech | sudo -S ip netns del golden $>/dev/null
sleep 5
check_interface_count=$(ifconfig |grep enp1s0 -c)

echo "Total Ethernet interface is: "$check_interface_count

if [ $check_interface_count -eq 1 ]; then
	echo "Setting GOLDEN namespace for enp1s0"
	echo vvdntech | sudo -S ip netns add golden
	echo vvdntech | sudo -S ip link set netns golden dev enp1s0
	echo vvdntech | sudo -S ip netns exec golden ip link set dev enp1s0 up
	echo vvdntech | sudo -S ip netns exec golden ip addr add 192.168.1.5/24 dev enp1s0
	check_golden_interface=$(echo vvdntech | sudo -S ip netns exec golden ifconfig |grep enp1s0 -c)
	if [ $check_golden_interface -eq 1 ]; then
		echo "GOLDEN namespace for enp1s0 DONE"
	else
		echo "GOLDEN namespace for enp1s0 NOT SET"
	fi
else
	echo "Check Ethernet cable connection"
fi
